import type { ActionFunction } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { useActionData } from "@remix-run/react";
import { TaskForm } from "~/components/TaskForm";
import { createTask } from "~/models/task.server";
import { z } from "zod";

const TaskSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  dueDate: z.string().optional().transform(val => val ? new Date(val) : null),
});

type ActionData = {
  error?: string;
};

export const action: ActionFunction = async ({ request }) => {
  const formData = await request.formData();
  const data = Object.fromEntries(formData);
  
  try {
    const validatedData = TaskSchema.parse(data);
    await createTask(validatedData);
    return redirect("/");
  } catch (error) {
    if (error instanceof z.ZodError) {
      return json<ActionData>({ error: error.errors[0].message });
    }
    return json<ActionData>({ error: "Failed to create task" });
  }
};

export default function NewTask() {
  const actionData = useActionData<ActionData>();

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-8">Create New Task</h1>
      <TaskForm error={actionData?.error} />
    </div>
  );
}