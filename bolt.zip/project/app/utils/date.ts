import { format, parseISO } from "date-fns";

export function formatDate(date: string | Date | null | undefined) {
  if (!date) return "";
  const dateObj = typeof date === "string" ? parseISO(date) : date;
  return format(dateObj, "PPP");
}