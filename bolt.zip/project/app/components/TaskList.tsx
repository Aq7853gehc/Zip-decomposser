import { Link } from "@remix-run/react";
import type { Task } from "~/models/task.server";
import { formatDate } from "~/utils/date";

interface TaskListProps {
  tasks: Task[];
}

export function TaskList({ tasks }: TaskListProps) {
  return (
    <div className="space-y-4">
      {tasks.map((task) => (
        <div
          key={task.id}
          className="bg-white p-4 rounded-lg shadow hover:shadow-md transition-shadow"
        >
          <Link to={`/tasks/${task.id}`} className="block">
            <h3 className="text-lg font-semibold text-gray-900">{task.title}</h3>
            {task.description && (
              <p className="mt-1 text-gray-600">{task.description}</p>
            )}
            <div className="mt-2 flex items-center justify-between text-sm text-gray-500">
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize" 
                style={{
                  backgroundColor: 
                    task.status === "completed" ? "rgb(209, 250, 229)" :
                    task.status === "in-progress" ? "rgb(254, 243, 199)" :
                    "rgb(243, 244, 246)",
                  color:
                    task.status === "completed" ? "rgb(6, 95, 70)" :
                    task.status === "in-progress" ? "rgb(146, 64, 14)" :
                    "rgb(31, 41, 55)"
                }}>
                {task.status}
              </span>
              {task.dueDate && (
                <span>Due: {formatDate(task.dueDate)}</span>
              )}
            </div>
          </Link>
        </div>
      ))}
    </div>
  );
}