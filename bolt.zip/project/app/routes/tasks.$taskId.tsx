import type { ActionFunction, LoaderFunction } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { Form, useActionData, useLoaderData } from "@remix-run/react";
import invariant from "tiny-invariant";
import { TaskForm } from "~/components/TaskForm";
import { deleteTask, getTask, updateTask } from "~/models/task.server";
import { z } from "zod";

type LoaderData = {
  task: NonNullable<Awaited<ReturnType<typeof getTask>>>;
};

const TaskSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  status: z.enum(["pending", "in-progress", "completed"]),
  dueDate: z.string().optional().transform(val => val ? new Date(val) : null),
});

export const loader: LoaderFunction = async ({ params }) => {
  invariant(params.taskId, "taskId not found");
  const task = await getTask(params.taskId);
  if (!task) {
    throw new Response("Not Found", { status: 404 });
  }
  return json<LoaderData>({ task });
};

type ActionData = {
  error?: string;
};

export const action: ActionFunction = async ({ request, params }) => {
  invariant(params.taskId, "taskId not found");
  
  if (request.method === "DELETE") {
    await deleteTask(params.taskId);
    return redirect("/");
  }

  const formData = await request.formData();
  const data = Object.fromEntries(formData);
  
  try {
    const validatedData = TaskSchema.parse(data);
    await updateTask(params.taskId, validatedData);
    return redirect("/");
  } catch (error) {
    if (error instanceof z.ZodError) {
      return json<ActionData>({ error: error.errors[0].message });
    }
    return json<ActionData>({ error: "Failed to update task" });
  }
};

export default function TaskDetails() {
  const { task } = useLoaderData<LoaderData>();
  const actionData = useActionData<ActionData>();

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Edit Task</h1>
        <Form method="delete">
          <button
            type="submit"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700"
            onClick={(e) => {
              if (!confirm("Are you sure you want to delete this task?")) {
                e.preventDefault();
              }
            }}
          >
            Delete Task
          </button>
        </Form>
      </div>
      <TaskForm task={task} error={actionData?.error} />
    </div>
  );
}