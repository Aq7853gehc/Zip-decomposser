import { prisma } from "~/db.server";
import type { Task } from "@prisma/client";

export type { Task } from "@prisma/client";

export async function getTasks() {
  return prisma.task.findMany({
    orderBy: { createdAt: "desc" },
  });
}

export async function getTask(id: string) {
  return prisma.task.findUnique({ where: { id } });
}

export async function createTask(
  data: Pick<Task, "title" | "description" | "dueDate">
) {
  return prisma.task.create({
    data: {
      title: data.title,
      description: data.description,
      dueDate: data.dueDate,
    },
  });
}

export async function updateTask(
  id: string,
  data: Pick<Task, "title" | "description" | "status" | "dueDate">
) {
  return prisma.task.update({
    where: { id },
    data,
  });
}

export async function deleteTask(id: string) {
  return prisma.task.delete({ where: { id } });
}