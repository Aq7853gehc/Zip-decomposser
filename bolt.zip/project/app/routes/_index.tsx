import type { LoaderFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Link, useLoaderData } from "@remix-run/react";
import { TaskList } from "~/components/TaskList";
import { getTasks } from "~/models/task.server";

type LoaderData = {
  tasks: Awaited<ReturnType<typeof getTasks>>;
};

export const loader: LoaderFunction = async () => {
  const tasks = await getTasks();
  return json<LoaderData>({ tasks });
};

export default function Index() {
  const { tasks } = useLoaderData<LoaderData>();

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Tasks</h1>
        <Link
          to="/tasks/new"
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
        >
          New Task
        </Link>
      </div>
      <TaskList tasks={tasks} />
    </div>
  );
}